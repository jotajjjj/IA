import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;

import aima.core.environment.nqueens.NQueensBoard;
import aima.core.environment.nqueens.NQueensGenAlgoUtil;
import aima.core.environment.nqueens.NQueensGoalTest;
import aima.core.environment.nqueens.NQueensGenAlgoUtil.NQueensGenAlgoGoalTest;
import aima.core.search.framework.problem.GoalTest;
import aima.core.search.local.FitnessFunction;
import aima.core.search.local.Individual;
import aima.core.util.datastructure.XYLocation;

public class TurnosExamenGenAlgoUtil {
	
	
	
	private static final int MAXTURNOS = 16;
	private static  int turnos;
	private static String[] profes;
	private static int [][] restric;
	private static int [][] prefer;
	
	public static FitnessFunction<Integer> getFitnessFunction() {
		return new TurnosExamenFitnessFunction ();
	}
	
	
	public static GoalTest getGoalTest() {
		return new TurnosExamenGenAlgoGoalTest();
	}
	
	
	/*
	 * -Para la funcion de fitnnes nos vamos a basar en, el numero de individuos diferentes entre si , de esa forma evitamos
	 * que un profesor evite repetir turnos
	 * - valoraremos con un +1 si ademas cumple que es una de sus preferencias
	 * 
	 */
	
	
	public static class TurnosExamenFitnessFunction implements FitnessFunction<Integer>{

		@Override
		public double apply(Individual<Integer> individual) {
			// TODO Auto-generated method stub
			double fitness =0;
			int profesDiferentes=numProfesoresDiferentes(individual) ;
			
			//NQueensBoard board = getBoardForIndividual(individual);
			
			
			int aciertoPreferencias=numeroPreferencias(individual);
			
			//int boardSize = 9;
			
			fitness=aciertoPreferencias+profesDiferentes;
			
			return fitness;
		}

		
		
	}
	
	public static int numProfesoresDiferentes(Individual<Integer> individual){
		
		int ret=0;
		
		Integer[] valores= new Integer [turnos];
		int iVal=0;
		
		
		
		for (int i = 0; i < individual.length(); i++) {
				
			int turno=individual.getRepresentation().get(i);
				
			//if(turno>8)
					///System.out.println("petaaaaaaa!!!!!");
			
				if(turno!=-1&&!profeConTurno(valores,turno)&&iVal<turnos){
					valores[iVal]=turno;
					ret++;
					iVal++;
				}
			
			
		}
		
		return  iVal;
		
	}
	
	public static int numeroPreferencias(Individual<Integer> individual){
		
		
		
		
		int ret=0;
		
		int profe=-1;
		
		
		for (int i = 0; i < MAXTURNOS; i++) {
			profe=individual.getRepresentation().get(i);
			
			for (int j = 0; j < MAXTURNOS-1 &&profe!=-1&&profe<8; j++) {
				
				//System.out.println(profe+"este es el profe");
				
				//System.out.println(j);
				
				//if(prefer[profe][j]>16)
					//System.out.println("Que pasa");
				
				int dia=individual.getRepresentation().get(prefer[profe][j]);
					if(prefer[profe][j]!=0&&profe==dia)
						ret++;
				
				
			}
			
			
		}
		
		
		
		return ret;
		
		
	}
	
	
	public static boolean profeConTurno(Integer  [] valores,int val){
		boolean ret=false;
		
		for (int i = 0; i < turnos; i++) {
			
			if(valores[i]!=null&&valores[i]==val)
				ret=true;
		}
		
		
		return ret;
	}
	
	
	
	public static class TurnosExamenGenAlgoGoalTest implements GoalTest {
		
		
		private final TurnosExamenGoalTest goalTest = new TurnosExamenGoalTest();

		@SuppressWarnings("unchecked")
		public boolean isGoalState(Object state) {
			return goalTest.isGoalState(getBoardForIndividual((Individual<Integer>) state));
			//return true;
		}
	}
	
	public static TurnosExamenBoard getBoardForIndividual(Individual<Integer> individual) {
		
		
		int boardSize = individual.length();
		TurnosExamenBoard board = new TurnosExamenBoard(boardSize);
		
			board.setHorario(individual.getRepresentation());
			board.setTurnos(turnos);
			

		return board;
	}
	
	
	public static Individual<Integer> generateRandomIndividual(int boardSize){
		
		ArrayList<Integer> individualRepresentation = new ArrayList<Integer>();
		//individualRepresentation=null;
		for (int i = 0; i < 16; i++) {
			individualRepresentation.add(-1);
		}
		
		int num = (int) (Math.random() * turnos-1);
		
		
		int i=0;
		while(i < num) {
			
			//int profesor=new Random().nextInt(profes.length);
			int profesor = (int) (Math.random() * profes.length);
		
				//System.out.println("profe: "+ profesor);
			
			//int turno=new Random().nextInt(MAXTURNOS);
			int turno = (int) (Math.random() * MAXTURNOS);
			
				//System.out.println("tunro: " +turno);
			
			if(!esRestriccion(profesor,turno)&&individualRepresentation.get(turno)==-1){
				
				individualRepresentation.set(turno, profesor);
				//solucion[turno]=profesor;
				i++;
			}
		
		}
		
		
		Individual<Integer> individual = new Individual<>(individualRepresentation);
		
		
		return individual;
		
		
		
		
	}
	
	
	public static Individual<Integer> generateSmartIndividual(int boardSize) {
		
		ArrayList<Integer> individualRepresentation = new ArrayList<Integer>();
		//individualRepresentation=null;
		for (int i = 0; i < 16; i++) {
			individualRepresentation.add(-1);
		}
		
		int i=0;
		
		while(i < turnos) {
			
			//int profesor=new Random().nextInt(profes.length);
			int profesor = (int) (Math.random() * profes.length);
		
				System.out.println("profe: "+ profesor);
			
			//int turno=new Random().nextInt(MAXTURNOS);
			int turno = (int) (Math.random() * MAXTURNOS);
			
				System.out.println("tunro: " +turno);
			
			if(!esRestriccion(profesor,turno)&&individualRepresentation.get(turno)==-1){
				
				individualRepresentation.set(turno, profesor);
				//solucion[turno]=profesor;
				i++;
			}
		
		}
		
		
		Individual<Integer> individual = new Individual<>(individualRepresentation);
		
		
		return individual;
	}
	
	public static boolean esRestriccion(int indi,int turno){
		
		//if(restric[indi][val]==0)
		
		boolean esRestriccion=false;
		
		for (int i = 0; i < MAXTURNOS; i++) {
			if(restric[indi][i]==turno)
				esRestriccion=true;
		}
		
		return  esRestriccion;
		
	}
	
	
	public static Collection<Integer> getFiniteAlphabetForBoardOfSize(int size) {
		Collection<Integer> fab = new ArrayList<Integer>();

		for (int i = 0; i < size; i++) {
			fab.add(i);
		}

		return fab;
	}

	public static void cargaDatos(String archivo) throws FileNotFoundException, IOException {
		int numero;
		String turnosStr;
		String cadena;
		String[] aux;
		String[] auxRest;
		String[] auxPref;
		
		FileReader f = new FileReader(archivo);
		BufferedReader b = new BufferedReader(f);

		turnosStr = b.readLine(); // lee el n�mero de profesores

		turnos = Integer.parseInt(turnosStr); // lo introduce en el atributo 

		cadena = b.readLine();
		profes = cadena.split(",");// mete el nombre de los profesores en el atributo profes

		// --------------------------RESTRICCIONES-------------------------------------
		int numeroProf = profes.length;
		restric = new int [numeroProf][MAXTURNOS];
		for (int i = 0; i < numeroProf; i++) {
			cadena = b.readLine(); // lEO TODA LA LINEA de profesor con sus restricciones

			aux = cadena.split(": "); // LA SEPARO EN DOS STRING

			if (aux.length > 1) { // si tine restricciones dicho profesor
				
				auxRest = aux[1].split(",");// ME QUEDO SOLO CON LA PARTE DE LOS N�MEROS y la meto en auxRest
				
				for (int j = 0; j < auxRest.length; j++) {
					numero = Integer.parseInt(auxRest[j]);
					restric[i][j] = numero;
				}
			} 
		}
		// si en la Matriz de restricciones aparece en las casillas el valor 0,es que no tiene restricciones
		
		//--------------------------PREFERENCIAS---------------------------------------------------
		prefer = new int [numeroProf][MAXTURNOS];
		for (int i = 0; i < numeroProf; i++) {
			cadena = b.readLine(); // lEO TODA LA LINEA de profesor con sus preferencias

			aux = cadena.split(": "); // LA SEPARO EN DOS STRING

			if (aux.length > 1) { // si tine preferencias dicho profesor
				
				auxPref = aux[1].split(",");// ME QUEDO SOLO CON LA PARTE DE LOS N�MEROS y la meto en auxPref
				
				for (int j = 0; j < auxPref.length; j++) {
					numero = Integer.parseInt(auxPref[j]);
					prefer[i][j] = numero;
				}
			} 
		}
		// si en la Matriz de preferencias aparece en las casillas el valor 0,es que no tiene restricciones
		b.close();
	}
	
	
	
	
}
