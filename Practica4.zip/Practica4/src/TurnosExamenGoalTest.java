import aima.core.environment.nqueens.NQueensBoard;
import aima.core.search.framework.problem.GoalTest;

public class TurnosExamenGoalTest implements GoalTest{
	
	
	
	@Override
	public boolean isGoalState(Object arg0) {
		// TODO Auto-generated method stub
		TurnosExamenBoard board = (TurnosExamenBoard) arg0;
		
		
		
		
		return board.getTurnos()==board.numTurnosUtilizados();
	}

}
