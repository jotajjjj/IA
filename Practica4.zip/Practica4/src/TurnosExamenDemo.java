import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

import aima.core.environment.nqueens.NQueensGenAlgoUtil;
import aima.core.search.framework.problem.GoalTest;
import aima.core.search.local.FitnessFunction;
import aima.core.search.local.GeneticAlgorithm;
import aima.core.search.local.Individual;

public class TurnosExamenDemo {

	private static final int Size = 16;
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TurnosExamenDemo();
	}
	private static void TurnosExamenDemo() {

		//nQueensWithDepthFirstSearch();
		//nQueensWithBreadthFirstSearch();
		//nQueensWithRecursiveDLS();
		//nQueensWithIterativeDeepeningSearch();
		//nQueensSimulatedAnnealingSearch();
		//nQueensHillClimbingSearch();
		turnosExamenGeneticAlgorithmSearch();
	}

	public static void turnosExamenGeneticAlgorithmSearch() {
		System.out.println("\turnosExamenDemo GeneticAlgorithm  -->");
		try {
			
			
			System.out.println("Escriba el fichero que quiere cargar");
			//String archivo = sc.nextLine();
			//carga.muestraContenido(/*archivo*/"configuracionConvocatoria1.txt");  
		
			
			
			
			TurnosExamenGenAlgoUtil.cargaDatos("configuracionConvocatoria1.txt");
			FitnessFunction<Integer> fitnessFunction = TurnosExamenGenAlgoUtil.getFitnessFunction();
			GoalTest goalTest = TurnosExamenGenAlgoUtil.getGoalTest();
			// Generate an initial population
			Set<Individual<Integer>> population = new HashSet<Individual<Integer>>();
			
			
			for (int i = 0; i < 50; i++) {
				//population.add(TurnosExamenGenAlgoUtil.generateSmartIndividual(16));
				population.add(TurnosExamenGenAlgoUtil.generateRandomIndividual(16));
			}
			
			
			//GeneticAlgorithm<Integer> ga = new GeneticAlgorithm<Integer>(Size,
					//TurnosExamenGenAlgoUtil.getFiniteAlphabetForBoardOfSize(Size), 0.9);
			
			TurnosExamenGeneticAlgorithm<Integer> ga = new TurnosExamenGeneticAlgorithm<Integer>(Size,
				TurnosExamenGenAlgoUtil.getFiniteAlphabetForBoardOfSize(Size), 0.15);
		
			
			
			// Run for a set amount of time
			Individual<Integer> bestIndividual = ga.geneticAlgorithm(population, fitnessFunction, goalTest, 1000L);

			System.out.println("Max Time (1 second) Best Individual=\n"
					+ TurnosExamenGenAlgoUtil.getBoardForIndividual(bestIndividual));
			System.out.println("Board Size      = " + Size);
			System.out.println("# Board Layouts = " + (new BigDecimal(Size)).pow(Size));
			System.out.println("Fitness         = " + fitnessFunction.apply(bestIndividual));
			System.out.println("Is Goal         = " + goalTest.isGoalState(bestIndividual));
			System.out.println("Population Size = " + ga.getPopulationSize());
			System.out.println("Itertions       = " + ga.getIterations());
			System.out.println("Took            = " + ga.getTimeInMilliseconds() + "ms.");

			// Run till goal is achieved
			bestIndividual = ga.geneticAlgorithm(population, fitnessFunction, goalTest, 0L);

			System.out.println("");
			System.out
					.println("Goal Test Best Individual=\n" + TurnosExamenGenAlgoUtil.getBoardForIndividual(bestIndividual));
			System.out.println("Board Size      = " + Size);
			System.out.println("# Board Layouts = " + (new BigDecimal(Size)).pow(Size));
			System.out.println("Fitness         = " + fitnessFunction.apply(bestIndividual));
			System.out.println("Is Goal         = " + goalTest.isGoalState(bestIndividual));
			System.out.println("Population Size = " + ga.getPopulationSize());
			System.out.println("Itertions       = " + ga.getIterations());
			System.out.println("Took            = " + ga.getTimeInMilliseconds() + "ms.");

		
		
		
		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
