import java.util.List;

public class TurnosExamenBoard {

		final int max=16;
		private int horario [];
		private int restricciones [][];
		private int turnos;
		private static String[] profes;
		public TurnosExamenBoard(int x){
			
			this.horario = new int [max];
			this.restricciones= new int  [max][max];
			
			for (int i = 0; i < x; i++) {
				this.horario[i]=0;
			}
		}
			
		public TurnosExamenBoard(){
			
			this.horario = new int [max];
			this.restricciones= new int  [max][max];
			
			for (int i = 0; i < horario.length; i++) {
				this.horario[i]=0;
			}
			
			
		}
		
		
		public void setHorario(List  b){
			
			for (int i = 0; i < max; i++) {
				this.horario[i]=(int) b.get(i);
			}
		}
		
		public void setTurnos(int n){
			this.turnos=n;
		}
		
		public int getTurnos(){
			
			return this.turnos;
		}
		public int numTurnosUtilizados(){
			int ret=0;
			
			
			for (int i = 0; i < horario.length; i++) {
				
				if(this.horario[i]!=-1)
					ret++;
				
			}
			return ret;
			
		}
		
		
		public void setProfes(String v []){
			
			for (int i = 0; i < v.length; i++) {
				this.profes[i]=v[i];
			}
			
		}
		
	public String toString(){
		
		String ret="";
			
		
		
		
		
		return ret;
	}
	
}
